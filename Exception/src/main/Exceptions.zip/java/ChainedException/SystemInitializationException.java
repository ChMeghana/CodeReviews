package ChainedException;

public class SystemInitializationException extends Exception {
    public SystemInitializationException(String message, Throwable cause) {
        super(message, cause);
    }
}

